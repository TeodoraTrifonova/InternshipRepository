package com.example.den4springbootapp.domain.models;

public class WeatherStation {
}

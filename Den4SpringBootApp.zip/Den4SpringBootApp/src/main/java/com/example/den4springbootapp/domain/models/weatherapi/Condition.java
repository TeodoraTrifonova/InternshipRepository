package com.example.den4springbootapp.domain.models.weatherapi;

public class Condition{
    public String text;
    public String icon;
    public int code;
}

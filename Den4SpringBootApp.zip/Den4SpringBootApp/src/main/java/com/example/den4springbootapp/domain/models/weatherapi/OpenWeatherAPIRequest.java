package com.example.den4springbootapp.domain.models.weatherapi;

import com.example.den4springbootapp.domain.models.weatherapi.Current;
import com.example.den4springbootapp.domain.models.weatherapi.Location;

public class OpenWeatherAPIRequest {
    public Location location;
    public Current current;
}

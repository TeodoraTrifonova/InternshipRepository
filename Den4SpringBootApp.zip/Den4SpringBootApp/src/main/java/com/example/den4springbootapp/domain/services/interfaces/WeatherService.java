package com.example.den4springbootapp.domain.services.interfaces;

public interface WeatherService {
}

package com.example.den4springbootapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Den4SpringBootAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(Den4SpringBootAppApplication.class, args);
    }

}

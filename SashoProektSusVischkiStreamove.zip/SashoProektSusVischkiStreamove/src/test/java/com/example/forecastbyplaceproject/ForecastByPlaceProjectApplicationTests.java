package com.example.forecastbyplaceproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ForecastByPlaceProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}

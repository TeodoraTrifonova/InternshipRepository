package com.example.forecastbyplaceproject.api.base;

public interface OperationResult {
}

package com.example.forecastbyplaceproject.data.entities.exception;

public class CustomException extends Exception{
    public CustomException(String message){
        super(message);
    }
}

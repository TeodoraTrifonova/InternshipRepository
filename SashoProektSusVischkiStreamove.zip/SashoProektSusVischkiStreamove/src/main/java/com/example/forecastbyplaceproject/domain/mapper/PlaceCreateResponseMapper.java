package com.example.forecastbyplaceproject.domain.mapper;

public class PlaceCreateResponseMapper {
}

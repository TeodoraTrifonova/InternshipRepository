package com.example.forecastbyplaceproject.data.services.crud.interfaces;

public interface DeleteService {
    void delete(Long id);
}

package com.example.forecastbyplaceproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ForecastByPlaceProjectApplication {

    public static void main(String[] args) {
        SpringApplication.run(ForecastByPlaceProjectApplication.class, args);
    }

}
